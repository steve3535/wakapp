#include<stdlib.h>
#include<stdio.h>

  main() {
    int ret;
    ret=system("id wakausr >/dev/null 2>&1");
    if (ret == 0){
      printf("\nEA01: Error: waka user seems to be present from a previous installation; kindly remove it with 'userdel -r wakausr' and reinstall the agent package\n");
      return; 
    }
    ret=system("useradd wakausr >/dev/null 2>&1 && mkdir /home/wakausr/.ssh && ssh-keygen -f /home/wakausr/.ssh/id_rsa -P '' >/dev/null 2>&1"); 
    if (ret != 0)
      printf("\nEA02: An error occured while installing the agent\n");
    else {
      system("echo 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCoXCZzkn42KvLKs8S+RdURntt/Xb4wv+m2dqEQUApOpKvjaZUTMCOrSI3Lhfz3VvzOXwHBUyh0f/fg51eJj4tjb7RN8wKTI5V3b+bKzdFiw0Wsl1udKSEABSVpUfdJfjRaOZs8P7LPgCt+sx5/jmXZ3SOoxC15ayzpr5QU2t0p8Li4Sd4l5QN6MUt9JwatONo45mfAWZO4T6lTwQMxvyTvf2IkWftDezBX4Yds1hgm1GEjn/oCmBEV5iM/lW4wCi7K4eiVAghgswiCjJcCvOPlXICaNd3A+mVM59y8rXi7WeUDkMBxWpwy50qoyBxqLORZH9LceCTyyMW6l3cw7rsp ansible-generated on rhel77' 2>/dev/null >/home/wakausr/.ssh/authorized_keys");
      system("chown -R wakausr.wakausr /home/wakausr/.ssh &&  chmod 700 /home/wakausr/.ssh && restorecon -FR /home/wakausr/.ssh");
    } 

    ret=system("grep '^wakausr' /etc/sudoers 2>&1>/dev/null");
    if (ret == 0)  system("sed -i 's/wakausr.*//g' /etc/sudoers 2>&1>/dev/null && echo 'wakausr ALL=(ALL)  NOPASSWD: ALL' >> /etc/sudoers");
    else system("cp /etc/sudoers /etc/sudoers.bak-$(date '+%Y%m%d') &&  echo 'wakausr ALL=(ALL)  NOPASSWD: ALL' >> /etc/sudoers");

  }

